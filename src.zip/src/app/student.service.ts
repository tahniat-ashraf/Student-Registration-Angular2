import { Injectable } from '@angular/core';
import { Http, Headers, Response } from "@angular/http";
import 'rxjs/Rx';
import { Observable } from "rxjs";

@Injectable()
export class StudentService {

  constructor(private _http: Http) { }

  url="/api/";

  // findMovie(movie) {
  //   this.totReqsMade = this.totReqsMade + 1;
  //   return this._http.get(this.findMovieURL1 + movie + this.findMovieURL2)
  //     .map(response => {
  //       { return response.json() };
  //     })
  //     .catch(error => Observable.throw(error.json().error));
  // }


  add(student){
    return this._http.post(this.url+"add",student)
      .map(response => {
        { return response };
      }).catch(error => Observable.throw(error.json()));

  }

  findAll(){
    return this._http.get(this.url)
      .map(response => {
        { return response.json() };
      }).catch(error => Observable.throw(error.json()));
  }

  delete(id:number){
    return this._http.get(this.url+"remove/"+id)
      .map(response => {
        { return response };
      }).catch(error => Observable.throw(error.json()));
  }

  edit(student){
    return this._http.post(this.url+"update",student)
      .map(response => {
        { return response };
      }).catch(error => Observable.throw(error.json()));
  }


}

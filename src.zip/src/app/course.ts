

export class Course{
  id : number;
  name : String
}

import {Course} from "./course";
export const COURSES: Course[] = [
  {id:1,name:"Anthropology"},
  {id:2,name:"Biology"},
  {id:3,name:"Chemisty"},
  {id:4,name:"Business"},
  {id:5,name:"Mathematics"},
  {id:6,name:"Cse"},

];

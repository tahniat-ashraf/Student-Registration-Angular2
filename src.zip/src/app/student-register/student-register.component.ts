import {Component, OnInit, Output, EventEmitter, ViewContainerRef, ViewChild} from '@angular/core';
import {StudentService} from "../student.service";
// import { Overlay } from 'angular2-modal';
// import { Modal } from 'angular2-modal/plugins/bootstrap';
import {ModalComponent} from "../modal.component";
import {COURSES} from "../course-list";


@Component({
  selector: 'app-student-register',
  templateUrl: './student-register.component.html',
  styleUrls: ['./student-register.component.css'],
  providers: [StudentService]
})
export class StudentRegisterComponent implements OnInit {

  // @ViewChild('myModal')
  // modal: ModalComponent;

  fname : any;
  lname;
  sid;
  nid;
  major;
  courses;
  errorText : String;
  @Output() onAdd = new EventEmitter<boolean>();
  @ViewChild(ModalComponent)
  public readonly mod: ModalComponent;


  // constructor(private studentService : StudentService,overlay: Overlay, vcRef: ViewContainerRef, public modal1: Modal) {
  //   overlay.defaultViewContainer = vcRef;
  //
  // }

  constructor(private studentService : StudentService) {

  }

  ngOnInit() {
    this.courses=COURSES;
  }

  register(){
    console.log('Clicked register button');
    console.log('fname : '+this.fname);
    var student={
      fname: this.fname,
      lname: this.lname,
      sid : this.sid,
      major: this.major
    };

    this.studentService.add(student)
      .subscribe(
        response => {
          console.log('RESPONSE : '+response);
          this.onAdd.emit(true);
          this.errorText='successful';
        },
        error => {
          console.log("ERROR :: register :: StudentRegisterComponent");
          console.log(error);
          this.mod.show();

        }
      );
  }



  register2(student){
    console.log('Clicked register (register2) with student : '+JSON.stringify(student));

    this.studentService.add(student)
      .subscribe(
        response => {
          console.log('RESPONSE : '+response);
          this.onAdd.emit(true);
          this.errorText='successful';
        },
        error => {
          console.log("ERROR :: register :: StudentRegisterComponent");
          console.log(error);
          this.mod.show();

        }
      );
  }




}
